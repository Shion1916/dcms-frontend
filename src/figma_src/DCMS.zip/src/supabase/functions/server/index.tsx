import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();
// Enable CORS for all routes
app.use(
  "*",
  cors({
    origin: "*",
    allowHeaders: ["*"],
    allowMethods: ["*"],
  }),
);
// Add logging
app.use("*", logger(console.log));
// Initialize demo data
async function initializeDemoData() {
  try {
    console.log("Checking for existing demo data...");
    // Always try to recreate demo data to ensure it's fresh
    const allUsers = await kv.getByPrefix("dcms:user:");
    console.log("Current users in database:", allUsers.length);
    console.log("Creating/updating demo data...");
    // Create demo users
    const demoUsers = [
      {
        email: "admin@localhost",
        user: {
          id: "admin-1",
          email: "admin@localhost",
          password: "c1$Vg4unme",
          first_name: "System",
          last_name: "Administrator",
          name: "System Administrator",
          role: "admin",
          canLogin: true,
          registrationType: "registered",
          createdAt: new Date().toISOString(),
          lastUpdatedAt: new Date().toISOString(),
        },
      },
      {
        email: "dentist@dentalclinic.com",
        user: {
          id: "dentist-1",
          email: "dentist@dentalclinic.com",
          password: "password123",
          first_name: "Sarah",
          last_name: "Johnson",
          name: "Dr. Sarah Johnson",
          role: "dentist",
          canLogin: true,
          registrationType: "registered",
          createdAt: new Date().toISOString(),
          lastUpdatedAt: new Date().toISOString(),
        },
      },
      {
        email: "staff@dentalclinic.com",
        user: {
          id: "staff-1",
          email: "staff@dentalclinic.com",
          password: "password123",
          first_name: "Mary",
          last_name: "Chen",
          name: "Mary Chen",
          role: "staff",
          canLogin: true,
          registrationType: "registered",
          createdAt: new Date().toISOString(),
          lastUpdatedAt: new Date().toISOString(),
        },
      },
      {
        email: "patient@example.com",
        user: {
          id: "patient-1",
          email: "patient@example.com",
          password: "password123",
          first_name: "John",
          last_name: "Smith",
          name: "John Smith",
          phone: "(555) 123-4567",
          role: "patient",
          canLogin: true,
          registrationType: "registered",
          createdAt: new Date().toISOString(),
          lastUpdatedAt: new Date().toISOString(),
        },
      },
      // Add some anonymous patients for demo
      {
        email: "jane@example.com",
        user: {
          id: "patient-2",
          email: "jane@example.com",
          password: null,
          first_name: "Jane",
          last_name: "Doe",
          name: "Jane Doe",
          phone: "(555) 987-6543",
          role: "patient",
          canLogin: false,
          registrationType: "anonymous",
          createdAt: new Date().toISOString(),
          lastUpdatedAt: new Date().toISOString(),
        },
      },
      {
        email: "mike@example.com",
        user: {
          id: "patient-3",
          email: "mike@example.com",
          password: null,
          first_name: "Mike",
          last_name: "Johnson",
          name: "Mike Johnson",
          phone: "(555) 456-7890",
          role: "patient",
          canLogin: false,
          registrationType: "anonymous",
          createdAt: new Date().toISOString(),
          lastUpdatedAt: new Date().toISOString(),
        },
      },
    ];
    // Create demo users
    for (const { email, user } of demoUsers) {
      await kv.set(`dcms:user:${email}`, user);
      console.log(`Created user: ${email} (${user.role})`);
    }
    // Create demo appointments with confirmed date/time data
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const dayAfter = new Date(today);
    dayAfter.setDate(dayAfter.getDate() + 2);
    const demoAppointments = [
      {
        id: "9f41f0bb-50d1-4933-b350-8a29e2b4e221",
        patientName: "John Smith",
        patientEmail: "patient@example.com",
        patientPhone: "(555) 123-4567",
        reason: "Routine checkup and cleaning",
        requestedDate: tomorrow.toISOString().split("T")[0],
        requestedTimeSlot: "10:00-11:15",
        date: tomorrow.toISOString().split("T")[0],
        time: "10:00",
        serviceDuration: 60,
        bufferTime: 15,
        dentistName: "Dr. Sarah Johnson",
        status: "booked",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_1",
            name: "Routine Cleaning",
            duration: 60,
            buffer: 15,
            base_price: 120,
            description:
              "Comprehensive dental cleaning and oral health examination with plaque and tartar removal",
          },
        ],
      },
      {
        id: "b1922b68-39d7-4f36-9e58-86d7c9e0e1f7",
        patientName: "Jane Doe",
        patientEmail: "jane@example.com",
        patientPhone: "(555) 987-6543",
        reason: "Dental filling",
        requestedDate: dayAfter.toISOString().split("T")[0],
        requestedTimeSlot: "14:00-15:00",
        date: dayAfter.toISOString().split("T")[0],
        time: "14:00",
        serviceDuration: 45,
        bufferTime: 15,
        dentistName: "Dr. Michael Chen",
        status: "booked",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_2",
            name: "Dental Filling",
            duration: 45,
            buffer: 15,
            base_price: 180,
            description:
              "Composite or amalgam filling for cavity restoration",
          },
        ],
      },
      {
        id: "c8a8507e-95c5-41d8-b91b-4a2ac09d56d9",
        patientName: "Mike Johnson",
        patientEmail: "mike@example.com",
        patientPhone: "(555) 456-7890",
        reason: "Teeth whitening",
        requestedDate: tomorrow.toISOString().split("T")[0],
        requestedTimeSlot: "13:30-14:45",
        date: tomorrow.toISOString().split("T")[0],
        time: "13:30",
        serviceDuration: 60,
        bufferTime: 15,
        dentistName: "Dr. Sarah Johnson",
        status: "booked",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_4",
            name: "Teeth Whitening",
            duration: 75,
            buffer: 15,
            base_price: 350,
            description:
              "Professional teeth whitening treatment for brighter smile",
          },
        ],
      },
      {
        id: "4fdb23af-2b68-492f-9c57-79c3447e86f2",
        patientName: "Sarah Wilson",
        patientEmail: "sarah@example.com",
        patientPhone: "(555) 234-5678",
        reason: "Emergency tooth pain",
        requestedDate: today.toISOString().split("T")[0],
        requestedTimeSlot: "09:00-10:00",
        date: today.toISOString().split("T")[0],
        time: "09:00",
        dentistName: "Dr. Emily Rodriguez",
        status: "cancelled",
        cancellationReason: "no-show",
        createdAt: new Date(
          Date.now() - 2 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_5",
            name: "Tooth Extraction",
            duration: 30,
            buffer: 20,
            base_price: 250,
            description:
              "Surgical or simple removal of damaged or problematic teeth",
          },
        ],
      },
      {
        id: "e97c3790-76d0-4c7c-9a25-9ac3a7a37d88",
        patientName: "Robert Brown",
        patientEmail: "robert@example.com",
        patientPhone: "(555) 345-6789",
        reason: "Dental crown fitting",
        requestedDate: dayAfter.toISOString().split("T")[0],
        requestedTimeSlot: "15:30-16:30",
        date: dayAfter.toISOString().split("T")[0],
        time: "15:30",
        dentistName: "Dr. David Kim",
        status: "cancelled",
        cancellationReason: "patient-cancelled",
        createdAt: new Date(
          Date.now() - 1 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_6",
            name: "Dental Crown",
            duration: 120,
            buffer: 30,
            base_price: 950,
            description:
              "Custom-made crown to restore damaged tooth structure and function",
          },
        ],
      },
      {
        id: "f5a9c4b3-0dc4-4ff1-81e2-ec08c8eb2a4a",
        patientName: "Lisa Garcia",
        patientEmail: "lisa@example.com",
        patientPhone: "(555) 456-7890",
        reason: "Routine cleaning",
        requestedDate: today.toISOString().split("T")[0],
        requestedTimeSlot: "11:00-12:00",
        date: today.toISOString().split("T")[0],
        time: "11:00",
        dentistName: "Dr. Sarah Johnson",
        status: "completed",
        createdAt: new Date(
          Date.now() - 3 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_1",
            name: "Routine Cleaning",
            duration: 60,
            buffer: 15,
            base_price: 120,
            description:
              "Comprehensive dental cleaning and oral health examination with plaque and tartar removal",
          },
        ],
      },
      {
        id: "2a497fc0-0c90-4703-bec3-5d746a9dcff2",
        patientName: "Michael Brown",
        patientEmail: "michael@example.com",
        patientPhone: "(555) 789-0123",
        reason: "Dental filling",
        requestedDate: today.toISOString().split("T")[0],
        requestedTimeSlot: "14:00-15:00",
        date: today.toISOString().split("T")[0],
        time: "14:00",
        dentistName: "Dr. Sarah Johnson",
        status: "completed",
        createdAt: new Date(
          Date.now() - 1 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_2",
            name: "Dental Filling",
            duration: 45,
            buffer: 15,
            base_price: 180,
            description:
              "Composite or amalgam filling for cavity restoration",
          },
        ],
      },
      {
        id: "8d3f4f91-fbd7-4786-a415-83d63f02fef0",
        patientName: "Emily Davis",
        patientEmail: "emily@example.com",
        patientPhone: "(555) 234-5678",
        reason: "Teeth whitening",
        requestedDate: today.toISOString().split("T")[0],
        requestedTimeSlot: "16:00-17:00",
        date: today.toISOString().split("T")[0],
        time: "16:00",
        dentistName: "Dr. Michael Chen",
        status: "completed",
        createdAt: new Date(
          Date.now() - 2 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_4",
            name: "Teeth Whitening",
            duration: 75,
            buffer: 15,
            base_price: 350,
            description:
              "Professional teeth whitening treatment for brighter smile",
          },
        ],
      },
      {
        id: "7f029ba8-aa38-4a2a-b18c-afe39e0b1f94",
        patientName: "Black Swan",
        patientEmail: "irayjb.07@gmail.com",
        patientPhone: "",
        reason: "Dental cleaning and extraction",
        requestedDate: today.toISOString().split("T")[0],
        requestedTimeSlot: "10:00-12:00",
        date: today.toISOString().split("T")[0],
        time: "10:00",
        dentistName: "Dr. Sarah Johnson",
        status: "completed",
        createdAt: new Date(
          Date.now() - 1 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        updatedAt: new Date().toISOString(),
        serviceDetails: [
          {
            id: "sc_1",
            name: "Routine Cleaning",
            duration: 60,
            buffer: 15,
            base_price: 120,
            description:
              "Comprehensive dental cleaning and oral health examination with plaque and tartar removal",
          },
          {
            id: "sc_5",
            name: "Tooth Extraction",
            duration: 30,
            buffer: 20,
            base_price: 250,
            description:
              "Surgical or simple removal of damaged or problematic teeth",
          },
        ],
      },
    ];
    // Create demo appointments
    for (const appointment of demoAppointments) {
      await kv.set(
        `dcms:appointment:${appointment.id}`,
        appointment,
      );
      console.log(
        `Created appointment: ${appointment.id} for ${appointment.patientName} on ${appointment.requestedDate || "pending"}`,
      );
    }
    // Set up patient appointment associations
    await kv.set("dcms:user-appointments:patient@example.com", [
      "apt-demo-1",
    ]);
    await kv.set("dcms:user-appointments:jane@example.com", [
      "apt-demo-2",
    ]);
    await kv.set("dcms:user-appointments:mike@example.com", [
      "apt-demo-3",
    ]);
    // Create demo services catalog
    const demoServices = [
      {
        id: "sc_1",
        name: "Routine Cleaning",
        description:
          "Comprehensive dental cleaning and oral health examination with plaque and tartar removal",
        base_price: 120,
        has_treatment_detail: false,
        estimated_duration: 60,
        buffer_time: 15,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_2",
        name: "Dental Filling",
        description:
          "Composite or amalgam filling for cavity restoration",
        base_price: 180,
        has_treatment_detail: true,
        estimated_duration: 45,
        buffer_time: 15,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_3",
        name: "Root Canal Treatment",
        description:
          "Endodontic therapy to treat infected or severely decayed teeth",
        base_price: 800,
        has_treatment_detail: true,
        estimated_duration: 90,
        buffer_time: 30,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_4",
        name: "Teeth Whitening",
        description:
          "Professional teeth whitening treatment for brighter smile",
        base_price: 350,
        has_treatment_detail: false,
        estimated_duration: 75,
        buffer_time: 15,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_5",
        name: "Tooth Extraction",
        description:
          "Surgical or simple removal of damaged or problematic teeth",
        base_price: 250,
        has_treatment_detail: true,
        estimated_duration: 30,
        buffer_time: 20,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_6",
        name: "Dental Crown",
        description:
          "Custom-made crown to restore damaged tooth structure and function",
        base_price: 950,
        has_treatment_detail: true,
        estimated_duration: 120,
        buffer_time: 30,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_7",
        name: "Orthodontic Consultation",
        description:
          "Initial consultation and assessment for braces or clear aligners",
        base_price: 150,
        has_treatment_detail: false,
        estimated_duration: 45,
        buffer_time: 15,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_8",
        name: "Dental Bridge",
        description:
          "Fixed prosthetic device to replace one or more missing teeth",
        base_price: 1200,
        has_treatment_detail: true,
        estimated_duration: 150,
        buffer_time: 30,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_9",
        name: "Periodontal Treatment",
        description:
          "Deep cleaning and treatment for gum disease and periodontal issues",
        base_price: 300,
        has_treatment_detail: true,
        estimated_duration: 90,
        buffer_time: 20,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "sc_10",
        name: "Dental Implant",
        description:
          "Permanent tooth replacement with titanium implant and crown",
        base_price: 2500,
        has_treatment_detail: true,
        estimated_duration: 180,
        buffer_time: 45,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];
    for (const service of demoServices) {
      await kv.set(
        `dcms:service-catalog:${service.id}`,
        service,
      );
      console.log(
        `Created service: ${service.name} (${service.base_price})`,
      );
    }
    // Create demo bills with fixed payment history for bill-477c14ec-14e5-40f1-b3ff-8b45d817416b
    const demoBills = [
      {
        id: "bill-demo-1",
        appointmentId: "apt-demo-6",
        patientId: "patient-demo-1",
        patientName: "Lisa Garcia",
        patientEmail: "lisa@example.com",
        patientPhone: "(555) 456-7890",
        items: [
          {
            id: "item-1",
            serviceId: "sc_1",
            serviceName: "Routine Cleaning",
            description:
              "Comprehensive dental cleaning and oral health examination",
            quantity: 1,
            unitPrice: 120,
            subtotal: 120,
          },
        ],
        totalAmount: 120,
        paidAmount: 120,
        outstandingBalance: 0,
        paymentMethod: "cash",
        status: "paid",
        notes: "Payment received in full",
        createdBy: "staff@dentalclinic.com",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "bill-demo-2",
        appointmentId: "apt-demo-7",
        patientId: "patient-demo-2",
        patientName: "Michael Brown",
        patientEmail: "michael@example.com",
        patientPhone: "(555) 123-4567",
        items: [
          {
            id: "item-2",
            serviceId: "sc_2",
            serviceName: "Dental Filling",
            description:
              "Composite filling for cavity restoration",
            quantity: 1,
            unitPrice: 180,
            subtotal: 180,
          },
        ],
        totalAmount: 180,
        paidAmount: 100,
        outstandingBalance: 80,
        paymentMethod: "card",
        status: "partial",
        notes: "Partial payment received, balance due",
        createdBy: "staff@dentalclinic.com",
        createdAt: new Date(
          Date.now() - 1 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        updatedAt: new Date(
          Date.now() - 1 * 24 * 60 * 60 * 1000,
        ).toISOString(),
      },
      {
        id: "bill-demo-3",
        appointmentId: "apt-demo-8",
        patientId: "patient-demo-3",
        patientName: "Emily Davis",
        patientEmail: "emily@example.com",
        patientPhone: "(555) 234-5678",
        items: [
          {
            id: "item-3",
            serviceId: "sc_4",
            serviceName: "Teeth Whitening",
            description:
              "Professional teeth whitening treatment",
            quantity: 1,
            unitPrice: 350,
            subtotal: 350,
          },
        ],
        totalAmount: 350,
        paidAmount: 0,
        outstandingBalance: 350,
        status: "pending",
        notes: "Bill generated, payment pending",
        createdBy: "staff@dentalclinic.com",
        createdAt: new Date(
          Date.now() - 2 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        updatedAt: new Date(
          Date.now() - 2 * 24 * 60 * 60 * 1000,
        ).toISOString(),
      },
      // Add the specific bill mentioned in the issue with complete payment history
      {
        id: "bill-477c14ec-14e5-40f1-b3ff-8b45d817416b",
        items: [
          {
            id: "item-sc_1",
            quantity: 1,
            subtotal: 120,
            serviceId: "sc_1",
            unitPrice: 120,
            description: "Comprehensive dental cleaning and oral health examination with plaque and tartar removal",
            serviceName: "Routine Cleaning"
          },
          {
            id: "item-sc_5",
            quantity: 2,
            subtotal: 500,
            serviceId: "sc_5",
            unitPrice: 250,
            description: "Surgical or simple removal of damaged or problematic teeth",
            serviceName: "Tooth Extraction"
          }
        ],
        notes: "",
        status: "paid",
        createdAt: "2025-09-18T12:16:03.818Z",
        createdBy: "admin@localhost",
        patientId: "anonymous",
        updatedAt: "2025-09-18T12:20:38.514Z",
        updatedBy: "admin@localhost",
        paidAmount: 620,
        patientName: "Black Swan",
        totalAmount: 620,
        patientEmail: "irayjb.07@gmail.com",
        patientPhone: "",
        appointmentId: "7f029ba8-aa38-4a2a-b18c-afe39e0b1f94",
        paymentMethod: "gcash",
        paymentHistory: [
          {
            id: "payment-1758197961288",
            notes: "Initial payment",
            amount: 500,
            paidAt: "2025-09-18T12:19:21.288Z",
            processedBy: "admin@localhost",
            paymentMethod: "cash"
          },
          {
            id: "payment-1758198025674",
            notes: "Additional payment",
            amount: 100,
            paidAt: "2025-09-18T12:20:25.674Z",
            processedBy: "admin@localhost",
            paymentMethod: "card"
          },
          {
            id: "payment-1758198038514",
            notes: "Final payment",
            amount: 20,
            paidAt: "2025-09-18T12:20:38.514Z",
            processedBy: "admin@localhost",
            paymentMethod: "gcash"
          }
        ],
        outstandingBalance: 0
      }
    ];
    for (const bill of demoBills) {
      await kv.set(`dcms:bill:${bill.id}`, bill);
      console.log(
        `Created bill: ${bill.id} for ${bill.patientName} (${bill.status})`,
      );
    }
    console.log("Demo data initialized successfully");
  } catch (error) {
    console.error("Error initializing demo data:", error);
  }
}
// Initialize demo data on startup (don't let failures crash the function)
initializeDemoData().catch((error) => {
  console.error(
    "Failed to initialize demo data - function will continue:",
    error,
  );
});

// Force overwrite of existing bill data to ensure the payment history is complete
async function forceBillUpdate() {
  try {
    // Force update the specific bill with complete payment history
    const fixedBill = {
      id: "bill-477c14ec-14e5-40f1-b3ff-8b45d817416b",
      items: [
        {
          id: "item-sc_1",
          quantity: 1,
          subtotal: 120,
          serviceId: "sc_1",
          unitPrice: 120,
          description: "Comprehensive dental cleaning and oral health examination with plaque and tartar removal",
          serviceName: "Routine Cleaning"
        },
        {
          id: "item-sc_5",
          quantity: 2,
          subtotal: 500,
          serviceId: "sc_5",
          unitPrice: 250,
          description: "Surgical or simple removal of damaged or problematic teeth",
          serviceName: "Tooth Extraction"
        }
      ],
      notes: "",
      status: "paid",
      createdAt: "2025-09-18T12:16:03.818Z",
      createdBy: "admin@localhost",
      patientId: "anonymous",
      updatedAt: "2025-09-18T12:20:38.514Z",
      updatedBy: "admin@localhost",
      paidAmount: 620,
      patientName: "Black Swan",
      totalAmount: 620,
      patientEmail: "irayjb.07@gmail.com",
      patientPhone: "",
      appointmentId: "7f029ba8-aa38-4a2a-b18c-afe39e0b1f94",
      paymentMethod: "gcash",
      paymentHistory: [
        {
          id: "payment-1758197961288",
          notes: "Initial payment",
          amount: 500,
          paidAt: "2025-09-18T12:19:21.288Z",
          processedBy: "admin@localhost",
          paymentMethod: "cash"
        },
        {
          id: "payment-1758198025674",
          notes: "Additional payment",
          amount: 100,
          paidAt: "2025-09-18T12:20:25.674Z",
          processedBy: "admin@localhost",
          paymentMethod: "card"
        },
        {
          id: "payment-1758198038514",
          notes: "Final payment",
          amount: 20,
          paidAt: "2025-09-18T12:20:38.514Z",
          processedBy: "admin@localhost",
          paymentMethod: "gcash"
        }
      ],
      outstandingBalance: 0
    };
    
    await kv.set(`dcms:bill:${fixedBill.id}`, fixedBill);
    console.log(`Force updated bill: ${fixedBill.id} with complete payment history`);
  } catch (error) {
    console.error("Error force updating bill:", error);
  }
}

// Force update the bill on startup
forceBillUpdate().catch((error) => {
  console.error("Failed to force update bill:", error);
});

// Simple test endpoint (no database calls)
app.get("/make-server-c89a26e4/test", (c) => {
  return c.json({
    status: "working",
    timestamp: new Date().toISOString(),
    message: "Function deployed successfully",
  });
});

// Server status and timestamp endpoint
app.get("/make-server-c89a26e4/server-status", (c) => {
  return c.json({
    status: "active",
    timestamp: new Date().toISOString(),
    version: "v2.1-merienda-debug",
    message:
      "Server function is running with enhanced merienda break debugging",
    breakTimes: [
      {
        start: "12:00",
        end: "13:00",
        name: "Lunch Break",
      },
      {
        start: "15:00",
        end: "15:15",
        name: "Merienda",
      },
    ],
  });
});

// Merienda break test endpoint
app.get("/make-server-c89a26e4/test-merienda", (c) => {
  try {
    // Test the merienda break logic with a fixed example
    const serviceDuration = 60;
    const bufferTime = 15;
    const totalServiceTime = serviceDuration + bufferTime; // 75 minutes
    // Define break times (same as in available-slots)
    const breakTimes = [
      {
        start: "12:00",
        end: "13:00",
        name: "Lunch Break",
      },
      {
        start: "15:00",
        end: "15:15",
        name: "Merienda",
      },
    ];
    // Convert break times to minutes
    const breakTimesParsed = breakTimes.map((breakTime) => ({
      startMinutes:
        parseInt(breakTime.start.split(":")[0]) * 60 +
        parseInt(breakTime.start.split(":")[1]),
      endMinutes:
        parseInt(breakTime.end.split(":")[0]) * 60 +
        parseInt(breakTime.end.split(":")[1]),
      name: breakTime.name,
    }));
    // Test specific slots that should be blocked by merienda
    const testSlots = [
      "13:45",
      "14:00",
      "14:15",
      "14:30",
      "15:00",
      "15:15",
      "15:30", // Should NOT conflict
    ];
    const results = testSlots.map((timeSlot) => {
      const [hour, minute] = timeSlot.split(":").map(Number);
      const startMinutes = hour * 60 + minute;
      const endMinutes = startMinutes + totalServiceTime;
      let conflicts = false;
      let conflictReason = "";
      // Check against merienda break specifically (900-915 minutes)
      const meriendaBreak = breakTimesParsed.find(
        (b) => b.name === "Merienda",
      );
      if (
        meriendaBreak &&
        startMinutes < meriendaBreak.endMinutes &&
        endMinutes > meriendaBreak.startMinutes
      ) {
        conflicts = true;
        conflictReason = `Conflicts with Merienda (${startMinutes}-${endMinutes} vs ${meriendaBreak.startMinutes}-${meriendaBreak.endMinutes})`;
      }
      return {
        time: timeSlot,
        startMinutes,
        endMinutes,
        conflicts,
        conflictReason: conflictReason || "No conflict",
        expected: timeSlot >= "14:00" && timeSlot <= "15:00", // Expected to conflict
      };
    });
    return c.json({
      status: "merienda-test-complete",
      timestamp: new Date().toISOString(),
      serviceConfig: {
        serviceDuration,
        bufferTime,
        totalServiceTime,
      },
      breakTimes: breakTimesParsed,
      results,
      summary: {
        totalTested: results.length,
        conflictsFound: results.filter((r) => r.conflicts)
          .length,
        expectedConflicts: results.filter((r) => r.expected)
          .length,
        correctResults: results.filter(
          (r) => r.conflicts === r.expected,
        ).length,
      },
    });
  } catch (error) {
    return c.json(
      {
        status: "error",
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      500,
    );
  }
});

// ============================================================================
// AUTHENTICATION ENDPOINTS
// ============================================================================

// Sign up endpoint
app.post("/make-server-c89a26e4/auth/signup", async (c) => {
  try {
    const {
      email,
      password,
      first_name,
      last_name,
      phone,
      requireEmailValidation,
      domain,
    } = await c.req.json();
    if (!email || !password || !first_name || !last_name) {
      return c.json(
        {
          error:
            "Email, password, first name, and last name are required",
        },
        400,
      );
    }
    // Check if user already exists
    const existingUser = await kv.get(`dcms:user:${email}`);
    if (existingUser) {
      return c.json(
        {
          error: "User with this email already exists",
        },
        409,
      );
    }
    // Generate validation token if email validation is required
    let validationToken = null;
    let validationLink = null;
    if (requireEmailValidation) {
      validationToken = crypto.randomUUID();
      validationLink = `${domain || "http://localhost:3000"}/validate-email?token=${validationToken}&email=${encodeURIComponent(email)}`;
      // Store validation token with expiry (24 hours)
      const expiryTime = new Date(
        Date.now() + 24 * 60 * 60 * 1000,
      );
      await kv.set(`dcms:email-validation:${validationToken}`, {
        email,
        first_name,
        last_name,
        password,
        phone: phone || null,
        expiresAt: expiryTime.toISOString(),
        createdAt: new Date().toISOString(),
      });
      // Create index for easier lookup
      await kv.set(
        `dcms:email-validation-index:${email}`,
        validationToken,
      );
    }
    // Create user object with computed name field for backward compatibility
    const fullName = `${first_name} ${last_name}`.trim();
    const userId = `user-${crypto.randomUUID()}`;
    const newUser = {
      id: userId,
      email,
      password,
      first_name,
      last_name,
      name: fullName,
      phone: phone || null,
      role: "patient",
      canLogin: requireEmailValidation ? false : true,
      registrationType: "registered",
      emailValidated: requireEmailValidation ? false : true,
      validationToken: requireEmailValidation
        ? validationToken
        : null,
      createdAt: new Date().toISOString(),
      lastUpdatedAt: new Date().toISOString(),
    };
    if (requireEmailValidation) {
      // Don't create the user yet, just return validation info
      console.log(
        `Signup initiated for ${email} - email validation required`,
      );
      return c.json({
        success: true,
        emailValidationRequired: true,
        validationLink,
        message: "Please check your email for validation link",
      });
    } else {
      // Create user immediately (fallback behavior)
      await kv.set(`dcms:user:${email}`, newUser);
      console.log(`Created user: ${email} (${newUser.role})`);
      return c.json({
        success: true,
        user: {
          id: newUser.id,
          email: newUser.email,
          first_name: newUser.first_name,
          last_name: newUser.last_name,
          name: newUser.name,
          phone: newUser.phone,
          role: newUser.role,
        },
      });
    }
  } catch (error) {
    console.error("Signup error:", error);
    return c.json(
      {
        error: "Internal server error during signup",
        details: error.message,
      },
      500,
    );
  }
});

// Sign in endpoint
app.post("/make-server-c89a26e4/auth/signin", async (c) => {
  try {
    const { email, password } = await c.req.json();
    if (!email || !password) {
      return c.json(
        { error: "Email and password are required" },
        400,
      );
    }
    // Get user from database
    const user = await kv.get(`dcms:user:${email}`);
    if (!user) {
      return c.json(
        { error: "Invalid email or password" },
        401,
      );
    }
    // Check if user can login
    if (!user.canLogin) {
      return c.json(
        { error: "Please verify your email before logging in" },
        401,
      );
    }
    // Verify password (in production, use proper password hashing)
    if (user.password !== password) {
      return c.json(
        { error: "Invalid email or password" },
        401,
      );
    }
    // Return user data (without password)
    const { password: _, ...userWithoutPassword } = user;
    return c.json({
      success: true,
      user: userWithoutPassword,
    });
  } catch (error) {
    console.error("Signin error:", error);
    return c.json(
      { error: "Internal server error during signin" },
      500,
    );
  }
});

// Email validation endpoint
app.post("/make-server-c89a26e4/auth/validate-email", async (c) => {
  try {
    const { token, email } = await c.req.json();
    if (!token || !email) {
      return c.json(
        { error: "Token and email are required" },
        400,
      );
    }
    // Get validation data
    const validationData = await kv.get(`dcms:email-validation:${token}`);
    if (!validationData || validationData.email !== email) {
      return c.json(
        { error: "Invalid or expired validation token" },
        400,
      );
    }
    // Check if token has expired
    const expiryTime = new Date(validationData.expiresAt);
    if (expiryTime < new Date()) {
      return c.json(
        { error: "Validation token has expired" },
        400,
      );
    }
    // Create user account
    const fullName = `${validationData.first_name} ${validationData.last_name}`.trim();
    const userId = `user-${crypto.randomUUID()}`;
    const newUser = {
      id: userId,
      email: validationData.email,
      password: validationData.password,
      first_name: validationData.first_name,
      last_name: validationData.last_name,
      name: fullName,
      phone: validationData.phone,
      role: "patient",
      canLogin: true,
      registrationType: "registered",
      emailValidated: true,
      validationToken: null,
      createdAt: new Date().toISOString(),
      lastUpdatedAt: new Date().toISOString(),
    };
    await kv.set(`dcms:user:${email}`, newUser);
    // Clean up validation data
    await kv.delete(`dcms:email-validation:${token}`);
    await kv.delete(`dcms:email-validation-index:${email}`);
    console.log(`Email validated and user created: ${email}`);
    return c.json({
      success: true,
      message: "Email validated successfully. You can now log in.",
    });
  } catch (error) {
    console.error("Email validation error:", error);
    return c.json(
      { error: "Internal server error during validation" },
      500,
    );
  }
});

// Resend validation endpoint
app.post("/make-server-c89a26e4/auth/resend-validation", async (c) => {
  try {
    const { email, domain } = await c.req.json();
    if (!email) {
      return c.json({ error: "Email is required" }, 400);
    }
    // Check if user already exists
    const existingUser = await kv.get(`dcms:user:${email}`);
    if (existingUser) {
      return c.json(
        { error: "User already exists and is validated" },
        400,
      );
    }
    // Get existing validation token
    const existingToken = await kv.get(`dcms:email-validation-index:${email}`);
    if (!existingToken) {
      return c.json(
        { error: "No pending validation found for this email" },
        400,
      );
    }
    // Generate new validation link
    const validationLink = `${domain || "http://localhost:3000"}/validate-email?token=${existingToken}&email=${encodeURIComponent(email)}`;
    return c.json({
      success: true,
      validationLink,
      message: "Validation email resent successfully",
    });
  } catch (error) {
    console.error("Resend validation error:", error);
    return c.json(
      { error: "Internal server error during resend" },
      500,
    );
  }
});

// ============================================================================
// APPOINTMENT ENDPOINTS
// ============================================================================

// Get all appointments
app.get("/make-server-c89a26e4/appointments", async (c) => {
  try {
    const appointments = await kv.getByPrefix("dcms:appointment:");
    
    // Sort by date and time, most recent first
    appointments.sort((a, b) => {
      const dateA = new Date(`${a.date || a.requestedDate} ${a.time || '00:00'}`);
      const dateB = new Date(`${b.date || b.requestedDate} ${b.time || '00:00'}`);
      return dateB.getTime() - dateA.getTime();
    });
    
    return c.json({
      success: true,
      appointments,
    });
  } catch (error) {
    console.error("Get appointments error:", error);
    return c.json(
      { error: "Failed to fetch appointments" },
      500,
    );
  }
});

// Get single appointment
app.get("/make-server-c89a26e4/appointments/:id", async (c) => {
  try {
    const appointmentId = c.req.param("id");
    const appointment = await kv.get(`dcms:appointment:${appointmentId}`);
    
    if (!appointment) {
      return c.json(
        { error: "Appointment not found" },
        404,
      );
    }
    
    return c.json({
      success: true,
      appointment,
    });
  } catch (error) {
    console.error("Get appointment error:", error);
    return c.json(
      { error: "Failed to fetch appointment" },
      500,
    );
  }
});

// Book appointment
app.post("/make-server-c89a26e4/appointments/book", async (c) => {
  try {
    const appointmentData = await c.req.json();
    
    // Generate unique appointment ID
    const appointmentId = crypto.randomUUID();
    
    // Create appointment object
    const appointment = {
      id: appointmentId,
      ...appointmentData,
      status: "booked",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Save appointment
    await kv.set(`dcms:appointment:${appointmentId}`, appointment);
    
    console.log(`Created appointment: ${appointmentId} for ${appointment.patientName}`);
    
    return c.json({
      success: true,
      appointment,
    });
  } catch (error) {
    console.error("Book appointment error:", error);
    return c.json(
      { error: "Failed to book appointment" },
      500,
    );
  }
});

// Update appointment
app.put("/make-server-c89a26e4/appointments/:id", async (c) => {
  try {
    const appointmentId = c.req.param("id");
    const updateData = await c.req.json();
    
    // Get existing appointment
    const existingAppointment = await kv.get(`dcms:appointment:${appointmentId}`);
    if (!existingAppointment) {
      return c.json(
        { error: "Appointment not found" },
        404,
      );
    }
    
    // Update appointment
    const updatedAppointment = {
      ...existingAppointment,
      ...updateData,
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`dcms:appointment:${appointmentId}`, updatedAppointment);
    
    return c.json({
      success: true,
      appointment: updatedAppointment,
    });
  } catch (error) {
    console.error("Update appointment error:", error);
    return c.json(
      { error: "Failed to update appointment" },
      500,
    );
  }
});

// Check available slots
app.get("/make-server-c89a26e4/appointments/available-slots", async (c) => {
  try {
    const url = new URL(c.req.url);
    const date = url.searchParams.get("date");
    const serviceDuration = parseInt(url.searchParams.get("serviceDuration") || "60");
    const bufferTime = parseInt(url.searchParams.get("bufferTime") || "15");
    
    if (!date) {
      return c.json(
        { error: "Date parameter is required" },
        400,
      );
    }
    
    // Get all appointments for the date
    const allAppointments = await kv.getByPrefix("dcms:appointment:");
    const appointmentsForDate = allAppointments.filter(
      apt => (apt.date || apt.requestedDate) === date && apt.status === "booked"
    );
    
    // Define clinic hours and break times
    const clinicStart = 8; // 8:00 AM
    const clinicEnd = 18; // 6:00 PM
    const timeSlotInterval = 15; // 15-minute intervals
    
    const breakTimes = [
      { start: "12:00", end: "13:00", name: "Lunch Break" },
      { start: "15:00", end: "15:15", name: "Merienda" },
    ];
    
    // Generate available time slots
    const slots = [];
    for (let hour = clinicStart; hour < clinicEnd; hour++) {
      for (let minute = 0; minute < 60; minute += timeSlotInterval) {
        const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        const startMinutes = hour * 60 + minute;
        const endMinutes = startMinutes + serviceDuration + bufferTime;
        
        // Check if slot conflicts with break times
        let conflicts = false;
        for (const breakTime of breakTimes) {
          const breakStart = parseInt(breakTime.start.split(':')[0]) * 60 + parseInt(breakTime.start.split(':')[1]);
          const breakEnd = parseInt(breakTime.end.split(':')[0]) * 60 + parseInt(breakTime.end.split(':')[1]);
          
          if (startMinutes < breakEnd && endMinutes > breakStart) {
            conflicts = true;
            break;
          }
        }
        
        // Check if slot conflicts with existing appointments
        if (!conflicts) {
          for (const apt of appointmentsForDate) {
            if (apt.time) {
              const aptStart = parseInt(apt.time.split(':')[0]) * 60 + parseInt(apt.time.split(':')[1]);
              const aptEnd = aptStart + (apt.serviceDuration || 60) + (apt.bufferTime || 15);
              
              if (startMinutes < aptEnd && endMinutes > aptStart) {
                conflicts = true;
                break;
              }
            }
          }
        }
        
        // Don't show slots that would extend past clinic hours
        if (endMinutes > clinicEnd * 60) {
          continue;
        }
        
        slots.push({
          time: timeString,
          available: !conflicts,
        });
      }
    }
    
    return c.json({
      success: true,
      date,
      slots,
    });
  } catch (error) {
    console.error("Get available slots error:", error);
    return c.json(
      { error: "Failed to get available slots" },
      500,
    );
  }
});

// Get appointment reports
app.get("/make-server-c89a26e4/appointments/reports", async (c) => {
  try {
    const url = new URL(c.req.url);
    const startDate = url.searchParams.get("startDate");
    const endDate = url.searchParams.get("endDate");
    
    // Get all appointments
    const allAppointments = await kv.getByPrefix("dcms:appointment:");
    
    // Filter by date range if provided
    let filteredAppointments = allAppointments;
    if (startDate && endDate) {
      filteredAppointments = allAppointments.filter(apt => {
        const aptDate = apt.date || apt.requestedDate;
        return aptDate >= startDate && aptDate <= endDate;
      });
    }
    
    // Calculate statistics
    const totalAppointments = filteredAppointments.length;
    const completedAppointments = filteredAppointments.filter(apt => apt.status === "completed").length;
    const cancelledAppointments = filteredAppointments.filter(apt => apt.status === "cancelled").length;
    const bookedAppointments = filteredAppointments.filter(apt => apt.status === "booked").length;
    
    // Calculate completion rate
    const completionRate = totalAppointments > 0 ? (completedAppointments / totalAppointments) * 100 : 0;
    
    return c.json({
      success: true,
      reports: {
        totalAppointments,
        completedAppointments,
        cancelledAppointments,
        bookedAppointments,
        completionRate: Math.round(completionRate * 100) / 100,
      },
      appointments: filteredAppointments,
    });
  } catch (error) {
    console.error("Get appointment reports error:", error);
    return c.json(
      { error: "Failed to get appointment reports" },
      500,
    );
  }
});

// Complete appointment
app.post("/make-server-c89a26e4/appointments/:id/complete", async (c) => {
  try {
    const appointmentId = c.req.param("id");
    const { notes, completedBy } = await c.req.json();
    
    // Get existing appointment
    const existingAppointment = await kv.get(`dcms:appointment:${appointmentId}`);
    if (!existingAppointment) {
      return c.json(
        { error: "Appointment not found" },
        404,
      );
    }
    
    // Update appointment status
    const updatedAppointment = {
      ...existingAppointment,
      status: "completed",
      completedAt: new Date().toISOString(),
      completedBy: completedBy || "Unknown",
      completionNotes: notes || "",
      updatedAt: new Date().toISOString(),
    };
    
    await kv.set(`dcms:appointment:${appointmentId}`, updatedAppointment);
    
    return c.json({
      success: true,
      appointment: updatedAppointment,
    });
  } catch (error) {
    console.error("Complete appointment error:", error);
    return c.json(
      { error: "Failed to complete appointment" },
      500,
    );
  }
});

// ============================================================================
// PATIENT ENDPOINTS
// ============================================================================

// Get all patients
app.get("/make-server-c89a26e4/patients", async (c) => {
  try {
    const users = await kv.getByPrefix("dcms:user:");
    const patients = users.filter(user => user.role === "patient");
    
    // Sort by creation date, most recent first
    patients.sort((a, b) => {
      const dateA = new Date(a.createdAt);
      const dateB = new Date(b.createdAt);
      return dateB.getTime() - dateA.getTime();
    });
    
    return c.json({
      success: true,
      patients,
    });
  } catch (error) {
    console.error("Get patients error:", error);
    return c.json(
      { error: "Failed to fetch patients" },
      500,
    );
  }
});

// Get single patient
app.get("/make-server-c89a26e4/patients/:id", async (c) => {
  try {
    const patientId = c.req.param("id");
    
    // Try to find patient by ID or email
    const users = await kv.getByPrefix("dcms:user:");
    const patient = users.find(user => 
      user.id === patientId || user.email === patientId
    );
    
    if (!patient || patient.role !== "patient") {
      return c.json(
        { error: "Patient not found" },
        404,
      );
    }
    
    return c.json({
      success: true,
      patient,
    });
  } catch (error) {
    console.error("Get patient error:", error);
    return c.json(
      { error: "Failed to fetch patient" },
      500,
    );
  }
});

// Create walk-in patient
app.post("/make-server-c89a26e4/patients/walk-in", async (c) => {
  try {
    const { first_name, last_name, email, phone } = await c.req.json();
    
    if (!first_name || !last_name || !email) {
      return c.json(
        { error: "First name, last name, and email are required" },
        400,
      );
    }
    
    // Check if patient already exists
    const existingUser = await kv.get(`dcms:user:${email}`);
    if (existingUser) {
      return c.json(
        { error: "Patient with this email already exists" },
        409,
      );
    }
    
    // Create patient
    const fullName = `${first_name} ${last_name}`.trim();
    const userId = `patient-${crypto.randomUUID()}`;
    const newPatient = {
      id: userId,
      email,
      password: null,
      first_name,
      last_name,
      name: fullName,
      phone: phone || null,
      role: "patient",
      canLogin: false,
      registrationType: "walk-in",
      createdAt: new Date().toISOString(),
      lastUpdatedAt: new Date().toISOString(),
    };
    
    await kv.set(`dcms:user:${email}`, newPatient);
    
    console.log(`Created walk-in patient: ${email}`);
    
    return c.json({
      success: true,
      patient: newPatient,
    });
  } catch (error) {
    console.error("Create walk-in patient error:", error);
    return c.json(
      { error: "Failed to create walk-in patient" },
      500,
    );
  }
});

// Update patient profile
app.put("/make-server-c89a26e4/patients/:id/profile", async (c) => {
  try {
    const patientId = c.req.param("id");
    const updateData = await c.req.json();
    
    // Find patient by ID or email
    const users = await kv.getByPrefix("dcms:user:");
    const patient = users.find(user => 
      user.id === patientId || user.email === patientId
    );
    
    if (!patient || patient.role !== "patient") {
      return c.json(
        { error: "Patient not found" },
        404,
      );
    }
    
    // Update patient data
    const updatedPatient = {
      ...patient,
      ...updateData,
      name: updateData.first_name && updateData.last_name 
        ? `${updateData.first_name} ${updateData.last_name}`.trim()
        : patient.name,
      lastUpdatedAt: new Date().toISOString(),
    };
    
    await kv.set(`dcms:user:${patient.email}`, updatedPatient);
    
    return c.json({
      success: true,
      patient: updatedPatient,
    });
  } catch (error) {
    console.error("Update patient profile error:", error);
    return c.json(
      { error: "Failed to update patient profile" },
      500,
    );
  }
});

// Validate patient email
app.post("/make-server-c89a26e4/patients/validate", async (c) => {
  try {
    const { email } = await c.req.json();
    
    if (!email) {
      return c.json(
        { error: "Email is required" },
        400,
      );
    }
    
    // Check if patient exists
    const patient = await kv.get(`dcms:user:${email}`);
    
    return c.json({
      success: true,
      exists: !!patient,
      patient: patient || null,
    });
  } catch (error) {
    console.error("Validate patient email error:", error);
    return c.json(
      { error: "Failed to validate patient email" },
      500,
    );
  }
});

// ============================================================================
// SERVICES ENDPOINTS
// ============================================================================

// Get all services
app.get("/make-server-c89a26e4/services", async (c) => {
  try {
    const services = await kv.getByPrefix("dcms:service-catalog:");
    
    // Sort by name
    services.sort((a, b) => a.name.localeCompare(b.name));
    
    return c.json({
      success: true,
      services,
    });
  } catch (error) {
    console.error("Get services error:", error);
    return c.json(
      { error: "Failed to fetch services" },
      500,
    );
  }
});

// ============================================================================
// BILLING ENDPOINTS
// ============================================================================

// Get all bills
app.get("/make-server-c89a26e4/billing", async (c) => {
  try {
    const bills = await kv.getByPrefix("dcms:bill:");
    
    // Sort by creation date, most recent first
    bills.sort((a, b) => {
      const dateA = new Date(a.createdAt);
      const dateB = new Date(b.createdAt);
      return dateB.getTime() - dateA.getTime();
    });
    
    return c.json({
      success: true,
      bills,
    });
  } catch (error) {
    console.error("Get bills error:", error);
    return c.json(
      { error: "Failed to fetch bills" },
      500,
    );
  }
});

// Get single bill
app.get("/make-server-c89a26e4/billing/:id", async (c) => {
  try {
    const billId = c.req.param("id");
    const bill = await kv.get(`dcms:bill:${billId}`);
    
    if (!bill) {
      return c.json(
        { error: "Bill not found" },
        404,
      );
    }
    
    return c.json({
      success: true,
      bill,
    });
  } catch (error) {
    console.error("Get bill error:", error);
    return c.json(
      { error: "Failed to fetch bill" },
      500,
    );
  }
});

// Update bill (including payment processing)
app.put("/make-server-c89a26e4/billing/:id", async (c) => {
  try {
    const billId = c.req.param("id");
    const updateData = await c.req.json();
    
    // Get existing bill
    const existingBill = await kv.get(`dcms:bill:${billId}`);
    if (!existingBill) {
      return c.json(
        { error: "Bill not found" },
        404,
      );
    }
    
    // Calculate new outstanding balance
    const newOutstandingBalance = existingBill.totalAmount - updateData.paidAmount;
    
    // Determine new status
    let newStatus = "pending";
    if (updateData.paidAmount >= existingBill.totalAmount) {
      newStatus = "paid";
    } else if (updateData.paidAmount > 0) {
      newStatus = "partial";
    }
    
    // Handle payment history update
    let paymentHistory = existingBill.paymentHistory || [];
    if (updateData.newPayment) {
      paymentHistory = [...paymentHistory, updateData.newPayment];
    }
    
    // Update bill
    const updatedBill = {
      ...existingBill,
      paidAmount: updateData.paidAmount,
      outstandingBalance: Math.max(0, newOutstandingBalance),
      status: newStatus,
      paymentMethod: updateData.paymentMethod || existingBill.paymentMethod,
      notes: updateData.notes || existingBill.notes,
      updatedBy: updateData.updatedBy || "Unknown",
      updatedAt: new Date().toISOString(),
      paymentHistory,
    };
    
    await kv.set(`dcms:bill:${billId}`, updatedBill);
    
    console.log(`Updated bill: ${billId} - Status: ${newStatus}`);
    
    return c.json({
      success: true,
      bill: updatedBill,
    });
  } catch (error) {
    console.error("Update bill error:", error);
    return c.json(
      { error: "Failed to update bill" },
      500,
    );
  }
});

// Create new bill
app.post("/make-server-c89a26e4/billing", async (c) => {
  try {
    const billData = await c.req.json();
    
    // Generate unique bill ID
    const billId = `bill-${crypto.randomUUID()}`;
    
    // Create bill object
    const bill = {
      id: billId,
      ...billData,
      paidAmount: 0,
      outstandingBalance: billData.totalAmount,
      status: "pending",
      paymentHistory: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Save bill
    await kv.set(`dcms:bill:${billId}`, bill);
    
    console.log(`Created bill: ${billId} for ${bill.patientName}`);
    
    return c.json({
      success: true,
      bill,
    });
  } catch (error) {
    console.error("Create bill error:", error);
    return c.json(
      { error: "Failed to create bill" },
      500,
    );
  }
});

// Get billing statistics
app.get("/make-server-c89a26e4/billing/stats", async (c) => {
  try {
    const bills = await kv.getByPrefix("dcms:bill:");
    
    const today = new Date().toISOString().split('T')[0];
    
    // Calculate stats
    const todaysBills = bills.filter(bill => 
      bill.createdAt.split('T')[0] === today
    );
    
    const totalBilledToday = todaysBills.reduce((sum, bill) => sum + bill.totalAmount, 0);
    const paymentsReceivedToday = todaysBills.reduce((sum, bill) => sum + bill.paidAmount, 0);
    const outstandingBalances = bills.reduce((sum, bill) => sum + bill.outstandingBalance, 0);
    
    return c.json({
      success: true,
      stats: {
        totalBilledToday,
        paymentsReceivedToday,
        outstandingBalances,
      },
    });
  } catch (error) {
    console.error("Get billing stats error:", error);
    return c.json(
      { error: "Failed to get billing statistics" },
      500,
    );
  }
});

// ============================================================================
// DASHBOARD ENDPOINTS
// ============================================================================

// Get dashboard statistics
app.get("/make-server-c89a26e4/dashboard", async (c) => {
  try {
    // Get all appointments
    const appointments = await kv.getByPrefix("dcms:appointment:");
    const bills = await kv.getByPrefix("dcms:bill:");
    const patients = await kv.getByPrefix("dcms:user:");
    
    const today = new Date().toISOString().split('T')[0];
    
    // Calculate appointment stats
    const todaysAppointments = appointments.filter(apt => 
      (apt.date || apt.requestedDate) === today
    );
    const totalAppointments = appointments.length;
    const completedAppointments = appointments.filter(apt => apt.status === "completed").length;
    const pendingAppointments = appointments.filter(apt => apt.status === "booked").length;
    
    // Calculate billing stats
    const totalRevenue = bills.reduce((sum, bill) => sum + bill.paidAmount, 0);
    const pendingPayments = bills.reduce((sum, bill) => sum + bill.outstandingBalance, 0);
    
    // Calculate patient stats
    const totalPatients = patients.filter(user => user.role === "patient").length;
    const newPatientsThisMonth = patients.filter(user => {
      if (user.role !== "patient") return false;
      const patientDate = new Date(user.createdAt);
      const currentDate = new Date();
      return patientDate.getMonth() === currentDate.getMonth() && 
             patientDate.getFullYear() === currentDate.getFullYear();
    }).length;
    
    return c.json({
      success: true,
      stats: {
        appointments: {
          today: todaysAppointments.length,
          total: totalAppointments,
          completed: completedAppointments,
          pending: pendingAppointments,
        },
        billing: {
          totalRevenue,
          pendingPayments,
        },
        patients: {
          total: totalPatients,
          newThisMonth: newPatientsThisMonth,
        },
      },
      recentAppointments: appointments
        .filter(apt => apt.status === "booked")
        .sort((a, b) => {
          const dateA = new Date(`${a.date || a.requestedDate} ${a.time || '00:00'}`);
          const dateB = new Date(`${b.date || b.requestedDate} ${b.time || '00:00'}`);
          return dateA.getTime() - dateB.getTime();
        })
        .slice(0, 5),
    });
  } catch (error) {
    console.error("Get dashboard stats error:", error);
    return c.json(
      { error: "Failed to get dashboard statistics" },
      500,
    );
  }
});

// ============================================================================
// DENTIST ENDPOINTS
// ============================================================================

// Get all dentists
app.get("/make-server-c89a26e4/dentists", async (c) => {
  try {
    const users = await kv.getByPrefix("dcms:user:");
    const dentists = users.filter(user => user.role === "dentist" || user.role === "admin");
    
    // Sort by name
    dentists.sort((a, b) => a.name.localeCompare(b.name));
    
    return c.json({
      success: true,
      dentists,
    });
  } catch (error) {
    console.error("Get dentists error:", error);
    return c.json(
      { error: "Failed to fetch dentists" },
      500,
    );
  }
});

// ============================================================================
// INVENTORY ENDPOINTS (Placeholder)
// ============================================================================

// Get inventory items
app.get("/make-server-c89a26e4/inventory", async (c) => {
  try {
    const inventory = await kv.getByPrefix("dcms:inventory:");
    
    return c.json({
      success: true,
      inventory: inventory || [],
    });
  } catch (error) {
    console.error("Get inventory error:", error);
    return c.json(
      { error: "Failed to fetch inventory" },
      500,
    );
  }
});

// ============================================================================
// MEDICAL RECORDS ENDPOINTS (Placeholder)
// ============================================================================

// Get medical records
app.get("/make-server-c89a26e4/medical-records", async (c) => {
  try {
    const records = await kv.getByPrefix("dcms:medical-record:");
    
    return c.json({
      success: true,
      records: records || [],
    });
  } catch (error) {
    console.error("Get medical records error:", error);
    return c.json(
      { error: "Failed to fetch medical records" },
      500,
    );
  }
});

// Start the server
export default app;